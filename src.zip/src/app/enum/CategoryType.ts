export enum CategoryType {
    "Books", "Food", "Clothes", "Accessories" , "Electronics", "Music", 
    "Beauty and Health", "Toys"
}
