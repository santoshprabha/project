package me.ignite.shopapi.service;

import me.ignite.shopapi.entity.ProductInOrder;
import me.ignite.shopapi.entity.User;


public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
