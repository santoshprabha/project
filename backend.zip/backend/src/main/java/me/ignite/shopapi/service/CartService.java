package me.ignite.shopapi.service;

import java.util.Collection;

import me.ignite.shopapi.entity.Cart;
import me.ignite.shopapi.entity.ProductInOrder;
import me.ignite.shopapi.entity.User;

public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
