package me.ignite.shopapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import me.ignite.shopapi.entity.ProductInOrder;


public interface ProductInOrderRepository extends JpaRepository<ProductInOrder, Long> {

}
