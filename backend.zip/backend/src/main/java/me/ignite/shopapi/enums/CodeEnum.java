package me.ignite.shopapi.enums;


public interface CodeEnum {
    Integer getCode();

}
